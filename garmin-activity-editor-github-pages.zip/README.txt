Garmin Activity Editor v2

This is a local, client-side Garmin FIT Set editor optimized for iPhone Safari.

Use:
1. Open index.html in Safari (or host this folder on any static HTTPS site).
2. Choose a .FIT activity from Files.
3. Use "Fix all Rest -> Round" or edit individual sets.
4. Save corrected FIT.
5. Import the resulting FIT into Garmin Connect.

The editor preserves underlying FIT records and only changes Garmin Set metadata.
Keep the original FIT as a backup.

Garmin's official FIT JavaScript SDK supports browser decoding/encoding. This prototype keeps the implementation self-contained so it can run without a server.
